package com.ashish.cryptocalc;

import androidx.lifecycle.ViewModel;

public class InputViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}