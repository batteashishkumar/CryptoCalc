package com.ashish.cryptocalc;

import androidx.lifecycle.ViewModel;

public class OutpuViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}