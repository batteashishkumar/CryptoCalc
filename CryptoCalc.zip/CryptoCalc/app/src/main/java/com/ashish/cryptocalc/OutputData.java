package com.ashish.cryptocalc;

public class OutputData {
    float Investment=0;
    float CoinsPurchased=0;
    float CoinsPurchasedinclBF=0;
    float BuyingFee=0;
    float RiskAmount=0;
    float WorseRiskAmount=0;
    float SellingFeeForRisk=0;
    float TotalAmountwithSF=0;
    float ProfitAmount=0;
    float ProfitAmountwithSF=0;
}
