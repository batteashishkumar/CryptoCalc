package com.ashish.cryptocalc;

import androidx.lifecycle.ViewModel;

public class SingleActivityViewModel extends ViewModel {
}
