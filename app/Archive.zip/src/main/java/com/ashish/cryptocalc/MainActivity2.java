package com.ashish.cryptocalc;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    BarChart barChart;
    ArrayList<String> xAxisLabel=null;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        CoinCapApi coinCapApi=new CoinCapApi(getApplicationContext());
//        coinCapApi.apiCall();
        barChart=findViewById(R.id.barchart);
        ArrayList<BarEntry> barEntries=new ArrayList<>();
        barEntries.add(new BarEntry(1,25.5f));
        barEntries.add(new BarEntry(2,22.8f));
        barEntries.add(new BarEntry(3,36.4f));
        barEntries.add(new BarEntry(4,31.2f));
        barEntries.add(new BarEntry(5,39.5f));
        barEntries.add(new BarEntry(6,43.3f));


        xAxisLabel = new ArrayList<>();
        xAxisLabel.add("2year");
        xAxisLabel.add("1year");
        xAxisLabel.add("60days");
        xAxisLabel.add("30days");
        xAxisLabel.add("7days");
        xAxisLabel.add("24h");
        xAxisLabel.add("Present");




        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM_INSIDE);

        ValueFormatter formatter = new ValueFormatter() {


            @Override
            public String getFormattedValue(float value) {
                return xAxisLabel.get((int) value);
            }
        };

        xAxis.setGranularity(1f); // minimum axis-step (interval) is 1
        xAxis.setValueFormatter(formatter);



        BarDataSet barDataSet=new BarDataSet(barEntries,"BitCoin");
        barDataSet.setColor(getColor(R.color.purple_very_light));
        barDataSet.setDrawValues(true);
        barDataSet.setValueTextSize(17);
        barChart.setData(new BarData(barDataSet));
        barChart.getAxisLeft().setDrawGridLines(false);
        barChart.getAxisRight().setDrawGridLines(false);
        barChart.animateY(3000);
        barChart.getDescription().setText(" ");
        barChart.getDescription().setTextColor(getColor(R.color.black_dark));



    }
}