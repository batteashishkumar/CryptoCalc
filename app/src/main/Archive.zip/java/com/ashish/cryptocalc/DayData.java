package com.ashish.cryptocalc;

public class DayData {
    public String date, opening,closing;
    public DayData(String date, String opening, String closing) {
        this.date=date;
        this.opening=opening;
        this.closing=closing;
    }
}
